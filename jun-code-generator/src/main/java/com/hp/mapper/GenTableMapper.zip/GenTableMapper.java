package com.hp.mapper;

import java.util.List;

import com.hp.domain.GenTable;
import com.hp.domain.GenTableColumn;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;

/**
 * 业务 数据层
 *
 * @author ruoyi
 */
@Mapper

public interface GenTableMapper
{
    /**
     * 查询业务列表
     *
     * @param genTable 业务信息
     * @return 业务集合
     */
    @Results(id="GenTableResult", value={
            //@Result(column="id", property="id", jdbcType= JdbcType.INTEGER, id=true),
            @Result(property="tableId"       ,column="table_id" , id=true),
            @Result(property="tableName"     ,column="table_name" ),
            @Result(property="tableComment"  ,column="table_comment"),
            @Result(property="subTableName"  ,column="sub_table_name"),
            @Result(property="subTableFkName",column="sub_table_fk_name"),
            @Result(property="className"     ,column="class_name" ),
            @Result(property="tplCategory"   ,column="tpl_category" ),
            @Result(property="packageName"   ,column="package_name" ),
            @Result(property="moduleName"    ,column="module_name"),
            @Result(property="businessName"  ,column="business_name"),
            @Result(property="functionName"  ,column="function_name"),
            @Result(property="functionAuthor",column="function_author"),
            @Result(property="genType"       ,column="gen_type" ),
            @Result(property="genPath"       ,column="gen_path" ),
            @Result(property="options"       ,column="options"  ),
            @Result(property="createBy"      ,column="create_by"),
            @Result(property="createTime"    ,column="create_time"),
            @Result(property="updateBy"      ,column="update_by"),
            @Result(property="updateTime"    ,column="update_time"),
            @Result(property="remark"        ,column="remark"   )/*,
            @Result(property="columns", javaType = List.class,typeHandler = GenTableColumn.class)*/
    })
    @Select("<script>" +
            " select table_id, table_name, table_comment, sub_table_name, sub_table_fk_name, class_name, tpl_category,\n" +
            "\t\tpackage_name, module_name, business_name, function_name, function_author, gen_type, gen_path, options,\n" +
            "\t\tcreate_by, create_time, update_by, update_time, remark from gen_table " +
            " <where>\n" +
            "\t\t\t<if test=\"tableName != null and tableName != ''\">\n" +
            "\t\t\t\tAND lower(table_name) like lower(concat('%', #{tableName}, '%'))\n" +
            "\t\t\t</if>\n" +
            "\t\t\t<if test=\"tableComment != null and tableComment != ''\">\n" +
            "\t\t\t\tAND lower(table_comment) like lower(concat('%', #{tableComment}, '%'))\n" +
            "\t\t\t</if>\n" +
            "\t\t\t<if test=\"params.beginTime != null and params.beginTime != ''\"><!-- 开始时间检索 -->\n" +
            "\t\t\t\tAND date_format(create_time,'%y%m%d') &gt;= date_format(#{params.beginTime},'%y%m%d')\n" +
            "\t\t\t</if>\n" +
            "\t\t\t<if test=\"params.endTime != null and params.endTime != ''\"><!-- 结束时间检索 -->\n" +
            "\t\t\t\tAND date_format(create_time,'%y%m%d') &lt;= date_format(#{params.endTime},'%y%m%d')\n" +
            "\t\t\t</if>\n" +
            "\t\t</where> "+
            "</script>")
    public List<GenTable> selectGenTableList(GenTable genTable);

    /**
     * 查询据库列表
     *
     * @param genTable 业务信息
     * @return 数据库表集合
     */
    @ResultMap(value="GenTableResult")
    @Select("<script>" +
            " select table_name, table_comment, create_time, update_time from information_schema.tables\n" +
            "\t\twhere table_schema = (select database())\n" +
            "\t\tAND table_name NOT LIKE 'qrtz_%' AND table_name NOT LIKE 'gen_%'\n" +
            "\t\tAND table_name NOT IN (select table_name from gen_table)\n" +
            "\t\t<if test=\"tableName != null and tableName != ''\">\n" +
            "\t\t\tAND lower(table_name) like lower(concat('%', #{tableName}, '%'))\n" +
            "\t\t</if>\n" +
            "\t\t<if test=\"tableComment != null and tableComment != ''\">\n" +
            "\t\t\tAND lower(table_comment) like lower(concat('%', #{tableComment}, '%'))\n" +
            "\t\t</if>\n" +
            "\t\t<if test=\"params.beginTime != null and params.beginTime != ''\"><!-- 开始时间检索 -->\n" +
            "\t\t\tAND date_format(create_time,'%y%m%d') &gt;= date_format(#{params.beginTime},'%y%m%d')\n" +
            "\t\t</if>\n" +
            "\t\t<if test=\"params.endTime != null and params.endTime != ''\"><!-- 结束时间检索 -->\n" +
            "\t\t\tAND date_format(create_time,'%y%m%d') &lt;= date_format(#{params.endTime},'%y%m%d')\n" +
            "\t\t</if>\n" +
            "        order by create_time desc "+
            "</script>")
    public List<GenTable> selectDbTableList(GenTable genTable);

    /**
     * 查询据库列表
     *
     * @param tableNames 表名称组
     * @return 数据库表集合
     */
    @ResultMap(value="GenTableResult")
     @Select("<script>" +
            " select table_name, table_comment, create_time, update_time from information_schema.tables\n" +
             "\t\twhere table_name NOT LIKE 'qrtz_%' and table_name NOT LIKE 'gen_%' and table_schema = (select database())\n" +
             "\t\tand table_name in\n" +
             "\t    <foreach collection=\"array\" item=\"name\" open=\"(\" separator=\",\" close=\")\">\n" +
             " \t\t\t#{name}\n" +
             "        </foreach> "+
            "</script>")
    public List<GenTable> selectDbTableListByNames(String[] tableNames);

    /**
     * 查询所有表信息
     *
     * @return 表信息集合
     */
    @ResultMap(value="GenTableResult")
    @Select("<script>" +
            " SELECT t.table_id, t.table_name, t.table_comment, t.sub_table_name, t.sub_table_fk_name, t.class_name, t.tpl_category, t.package_name, t.module_name, t.business_name, t.function_name, t.function_author, t.options, t.remark,\n" +
            "\t\t\t   c.column_id, c.column_name, c.column_comment, c.column_type, c.java_type, c.java_field, c.is_pk, c.is_increment, c.is_required, c.is_insert, c.is_edit, c.is_list, c.is_query, c.query_type, c.html_type, c.dict_type, c.sort\n" +
            "\t\tFROM gen_table t\n" +
            "\t\t\t LEFT JOIN gen_table_column c ON t.table_id = c.table_id\n" +
            "\t\torder by c.sort "+
            "</script>")
    public List<GenTable> selectGenTableAll();

    /**
     * 查询表ID业务信息
     *
     * @param tableId 业务ID
     * @return 业务信息
     */
    @ResultMap(value="GenTableResult")
    @Select("<script>" +
            " SELECT t.table_id, t.table_name, t.table_comment, t.sub_table_name, t.sub_table_fk_name, t.class_name, t.tpl_category, t.package_name, t.module_name, t.business_name, t.function_name, t.function_author, t.gen_type, t.gen_path, t.options, t.remark,\n" +
            "\t\t\t   c.column_id, c.column_name, c.column_comment, c.column_type, c.java_type, c.java_field, c.is_pk, c.is_increment, c.is_required, c.is_insert, c.is_edit, c.is_list, c.is_query, c.query_type, c.html_type, c.dict_type, c.sort\n" +
            "\t\tFROM gen_table t\n" +
            "\t\t\t LEFT JOIN gen_table_column c ON t.table_id = c.table_id\n" +
            "\t\twhere t.table_id = #{tableId} order by c.sort "+
            "</script>")
    public GenTable selectGenTableById(@Param(value = "tableId") Long tableId);

    /**
     * 查询表名称业务信息
     *
     * @param tableName 表名称
     * @return 业务信息
     */
    @ResultMap(value="GenTableResult")
    @Select("<script>" +
            " SELECT t.table_id, t.table_name, t.table_comment, t.sub_table_name, t.sub_table_fk_name, t.class_name, t.tpl_category, t.package_name, t.module_name, t.business_name, t.function_name, t.function_author, t.gen_type, t.gen_path, t.options, t.remark,\n" +
            "\t\t\t   c.column_id, c.column_name, c.column_comment, c.column_type, c.java_type, c.java_field, c.is_pk, c.is_increment, c.is_required, c.is_insert, c.is_edit, c.is_list, c.is_query, c.query_type, c.html_type, c.dict_type, c.sort\n" +
            "\t\tFROM gen_table t\n" +
            "\t\t\t LEFT JOIN gen_table_column c ON t.table_id = c.table_id\n" +
            "\t\twhere t.table_name = #{tableName} order by c.sort "+
            "</script>")
    public GenTable selectGenTableByName(String tableName);

    /**
     * 新增业务
     *
     * @param genTable 业务信息
     * @return 结果
     */
    @Insert("<script>" +
            "  insert into gen_table (\n" +
            "\t\t\t<if test=\"tableName != null\">table_name,</if>\n" +
            "\t\t\t<if test=\"tableComment != null and tableComment != ''\">table_comment,</if>\n" +
            "\t\t\t<if test=\"className != null and className != ''\">class_name,</if>\n" +
            "\t\t\t<if test=\"tplCategory != null and tplCategory != ''\">tpl_category,</if>\n" +
            "\t\t\t<if test=\"packageName != null and packageName != ''\">package_name,</if>\n" +
            "\t\t\t<if test=\"moduleName != null and moduleName != ''\">module_name,</if>\n" +
            "\t\t\t<if test=\"businessName != null and businessName != ''\">business_name,</if>\n" +
            "\t\t\t<if test=\"functionName != null and functionName != ''\">function_name,</if>\n" +
            "\t\t\t<if test=\"functionAuthor != null and functionAuthor != ''\">function_author,</if>\n" +
            "\t\t\t<if test=\"genType != null and genType != ''\">gen_type,</if>\n" +
            "\t\t\t<if test=\"genPath != null and genPath != ''\">gen_path,</if>\n" +
            "\t\t\t<if test=\"remark != null and remark != ''\">remark,</if>\n" +
            " \t\t\t<if test=\"createBy != null and createBy != ''\">create_by,</if>\n" +
            "\t\t\tcreate_time\n" +
            "         )values(\n" +
            "\t\t\t<if test=\"tableName != null\">#{tableName},</if>\n" +
            "\t\t\t<if test=\"tableComment != null and tableComment != ''\">#{tableComment},</if>\n" +
            "\t\t\t<if test=\"className != null and className != ''\">#{className},</if>\n" +
            "\t\t\t<if test=\"tplCategory != null and tplCategory != ''\">#{tplCategory},</if>\n" +
            "\t\t\t<if test=\"packageName != null and packageName != ''\">#{packageName},</if>\n" +
            "\t\t\t<if test=\"moduleName != null and moduleName != ''\">#{moduleName},</if>\n" +
            "\t\t\t<if test=\"businessName != null and businessName != ''\">#{businessName},</if>\n" +
            "\t\t\t<if test=\"functionName != null and functionName != ''\">#{functionName},</if>\n" +
            "\t\t\t<if test=\"functionAuthor != null and functionAuthor != ''\">#{functionAuthor},</if>\n" +
            "\t\t\t<if test=\"genType != null and genType != ''\">#{genType},</if>\n" +
            "\t\t\t<if test=\"genPath != null and genPath != ''\">#{genPath},</if>\n" +
            "\t\t\t<if test=\"remark != null and remark != ''\">#{remark},</if>\n" +
            " \t\t\t<if test=\"createBy != null and createBy != ''\">#{createBy},</if>\n" +
            "\t\t\tsysdate()\n" +
            "         )  "+
            "</script>")
    @Options(useGeneratedKeys = true,keyProperty = "tableId")
    //@SelectKey(statement = "select last_insert_id()", keyProperty = "id", keyColumn = "id", resultType = int,before = false)
    public int insertGenTable(GenTable genTable);

    /**
     * 修改业务
     *
     * @param genTable 业务信息
     * @return 结果
     */
    @Update("<script>" +
            " update gen_table\n" +
            "        <set>\n" +
            "            <if test=\"tableName != null\">table_name = #{tableName},</if>\n" +
            "            <if test=\"tableComment != null and tableComment != ''\">table_comment = #{tableComment},</if>\n" +
            "            <if test=\"subTableName != null\">sub_table_name = #{subTableName},</if>\n" +
            "            <if test=\"subTableFkName != null\">sub_table_fk_name = #{subTableFkName},</if>\n" +
            "            <if test=\"className != null and className != ''\">class_name = #{className},</if>\n" +
            "            <if test=\"functionAuthor != null and functionAuthor != ''\">function_author = #{functionAuthor},</if>\n" +
            "            <if test=\"genType != null and genType != ''\">gen_type = #{genType},</if>\n" +
            "            <if test=\"genPath != null and genPath != ''\">gen_path = #{genPath},</if>\n" +
            "            <if test=\"tplCategory != null and tplCategory != ''\">tpl_category = #{tplCategory},</if>\n" +
            "            <if test=\"packageName != null and packageName != ''\">package_name = #{packageName},</if>\n" +
            "            <if test=\"moduleName != null and moduleName != ''\">module_name = #{moduleName},</if>\n" +
            "            <if test=\"businessName != null and businessName != ''\">business_name = #{businessName},</if>\n" +
            "            <if test=\"functionName != null and functionName != ''\">function_name = #{functionName},</if>\n" +
            "            <if test=\"options != null and options != ''\">options = #{options},</if>\n" +
            "            <if test=\"updateBy != null and updateBy != ''\">update_by = #{updateBy},</if>\n" +
            "            <if test=\"remark != null\">remark = #{remark},</if>\n" +
            "            update_time = sysdate()\n" +
            "        </set>\n" +
            "        where table_id = #{tableId}  "+
            "</script>")
    public int updateGenTable(GenTable genTable);

    /**
     * 批量删除业务
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Delete("<script>" +
            "  delete from gen_table where table_id in\n" +
            "        <foreach collection=\"array\" item=\"tableId\" open=\"(\" separator=\",\" close=\")\">\n" +
            "            #{tableId}\n" +
            "        </foreach> "+
            "</script>")
    public int deleteGenTableByIds(Long[] ids);
}
